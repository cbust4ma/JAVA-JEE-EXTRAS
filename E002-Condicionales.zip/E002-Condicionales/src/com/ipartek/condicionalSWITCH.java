package com.ipartek;

public class condicionalSWITCH {

	public static void main(String[] args) {
		
		int numero=7;
		
		switch(numero)
		{
			case 1:System.out.println("es 1");break;
			case 2:System.out.println("es 2");break;
			case 3:System.out.println("es 3");break;
			case 4:System.out.println("es 4");break;
			case 5:System.out.println("es 5");break;
			case 6:System.out.println("es 6");break;
			default:System.out.println("TRAMPOSO");break;
		}

		
		char letra='b';
		switch(letra)
		{
		case 'a':System.out.println("es la A");break;
		case 'b':System.out.println("es la B");break;
		case 'c':System.out.println("es la C");break;
		default:System.out.println("OTRA LETRA");break;
		
		}
		
		
		String nombre="Alain";
		switch (nombre) {
		case "Alain":System.out.println("Usuario ALAIN");break;
		case "Jose":System.out.println("Usuario JOSE");break;
		case "Ana":System.out.println("Usuario ANA");break;
		case "Julia":System.out.println("Usuario JULIA");break;
		default:System.out.println("Usuario no encontrado");break;
		}
		
	}

}
