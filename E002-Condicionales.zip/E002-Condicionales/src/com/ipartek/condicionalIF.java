package com.ipartek;

public class condicionalIF {

	public static void main(String[] args) {

		int numero1 = 8;
		int numero2 = 7;

		if (numero1 > numero2) {
			System.out.println("el numero 1 es mayor");
		}

		if (numero1 > numero2) {
			System.out.println("el numero 1 es mayor");
		} else {
			System.out.println("el numero 1 es menor o igual");
		}

		if (numero1 > numero2) {
			System.out.println("el numero 1 es mayor");
		} else if (numero1 == numero2) {
			System.out.println("son iguales");
		} else if (numero1 < numero2) {
			System.out.println("el numero 1 es menor");
		}
		
		
	}

}
