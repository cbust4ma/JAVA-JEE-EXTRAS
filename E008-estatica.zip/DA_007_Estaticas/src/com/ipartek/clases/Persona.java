package com.ipartek.clases;

public class Persona {
	
	private static int contador;
	private String nombre;
	private int edad;
	
	
	public Persona(String nombre, int edad) {
		super();
		this.contador= contador+1;
		this.nombre = nombre;
		this.edad = edad;
	}
	
	public Persona() {
		super();
		this.contador= contador+1;
		this.nombre = "";
		this.edad = 0;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public static int getContador() {
		return contador;
	}

	@Override
	public String toString() {
		return "Persona numero:"+contador+" [nombre=" + nombre + ", edad=" + edad + "]";
	}
	
	
	
	public static void comprobarAforo()
	{
		if (contador>4) {
			System.out.println("Aforo completo, tu sabras lo que haces");
		}
		else
		{
			System.out.println("aun entra gente");
		}
		
	}
	

}
