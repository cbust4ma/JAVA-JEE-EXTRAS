package com.ipartek.clases;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Persona p1 = new Persona("Laura",43);
		Persona p2 = new Persona("Juan", 22);
		Persona p3 = new Persona("Ana", 25);
		Persona p4 = new Persona("Adolfo",12);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
		
		//p1.comprobarAforo();// no es lo mas correcto
		
		Persona.comprobarAforo();
		
		Persona p5 = new Persona("Rick",67);
		
		Persona.comprobarAforo();
		
		

	}

}
