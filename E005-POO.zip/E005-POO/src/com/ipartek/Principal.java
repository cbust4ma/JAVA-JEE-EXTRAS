package com.ipartek;

public class Principal {

	public static void main(String[] args) {
	
		int i=0;
		
		Pelicula peli= new Pelicula();
		peli.setTitulo("Matrix");
		peli.setDuracion(121);
		peli.setFormato("VHS");
		
		System.out.println("pelicula: "+peli);
		
		System.out.println(peli.getTitulo()+", "+peli.getDuracion()
		+", "+peli.getFormato());
		
		
		Pelicula peli2 = new Pelicula("GITS", 105, "DVD"); 
		
		

	}

}
