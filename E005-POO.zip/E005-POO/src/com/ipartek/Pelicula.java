package com.ipartek;

public class Pelicula {

	private String titulo;
	private int duracion;
	private String formato;

	public Pelicula(String titulo, int duracion, String formato) {
		this.titulo = titulo;
		this.duracion = duracion;
		this.formato = formato;
	}

	public Pelicula() {
		this.titulo = "";
		this.duracion = 0;
		this.formato = "";
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	@Override
	public String toString() {
		return "titulo=" + titulo + ", duracion=" + duracion + ", formato=" + formato ;
	}
	
	

}
