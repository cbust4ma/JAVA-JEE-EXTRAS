package com.ipartek;

import java.io.FileWriter;
import java.io.IOException;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fichero_Helper fh= new Fichero_Helper();
		
		FileWriter writer=fh.conectar();
		
		//deberia haberse leido por teclado
		Pokemon poke= new Pokemon(1, "Bulbasaur", "Planta");
		Pokemon poke3= new Pokemon(34, "a", "Planta");
		boolean encontado=fh.buscarPokemon(poke3);
		
		System.out.println("Encontrado="+encontado);
		
		fh.desconectar(writer);
		
	}

}
