package com.ipartek;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Fichero_Helper implements I_Conexion {

	@Override
	public FileWriter conectar() {
		File file = new File(RUTA + NOMBRE);
		FileWriter writer;
		try {
			file.createNewFile();
			writer = new FileWriter(file, true);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		System.out.println("conectado");
		return writer;
	}

	@Override
	public void desconectar(FileWriter writer) {
		try {
			writer.flush();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("desconectar");
	}

	@Override
	public void guardarPokemon(Pokemon poke, FileWriter writer) {
		try {
			writer.write(poke.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("se añadio el pokemon" + poke);
	}

	@Override
	public boolean buscarPokemon(Pokemon poke) {
		File file = new File(RUTA + NOMBRE);
		try {
			FileReader fr = new FileReader(file);
			
			BufferedReader br = new BufferedReader(fr);
			String linea = "";

			while ((linea = br.readLine()) != null) {

				if (linea.equalsIgnoreCase(poke.toString().trim())) {
				
					return true;
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public boolean buscarPokemon(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean buscarPokemon(String nombre) {
		// TODO Auto-generated method stub
		return false;
	}

}
