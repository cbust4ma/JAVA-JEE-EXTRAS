package com.ipartek;

import java.io.File;
import java.io.FileWriter;

public interface I_Conexion {
	
	String RUTA = "C:/Alain/";
	String NOMBRE = "log.txt";


	public abstract FileWriter conectar();
	public abstract void desconectar(FileWriter writer);
	public abstract void guardarPokemon(Pokemon poke,FileWriter writer);
	public abstract boolean buscarPokemon(Pokemon poke);
	
	
	public abstract boolean buscarPokemon(int id);
	public abstract boolean buscarPokemon(String nombre);
	
	
	
}
