package com.ipartek;

public class Principal {

	public static void main(String[] args) {
		//comentario de una linea
		
		/*
		 * Comentario multi linea
		 * podemos dar explicaciones mas largas
		 * por si necesitamos
		 */
		
		/**
		 *Javadoc. estos comentarios son para documentar 
		 */
		
		
		//variables
		//numeros enteros
		byte numeroByte = 127;// 1 byte
		
		short numeroShort= 4532;// 2 bytes
		
		int numeroInt= 165445643;// 4 bytes
		
		long numeroLong=27237476345544L;// 8 bytes
		
		float numeroReal=2.6F;// 4 bytes
		double numeroDouble=7.98;// 8 bytes
		
		//texto
		char letra='a'; // 2 bytes
		char otraLetra=65535;
		char otraLetraUnicode='\u5463';
		
		String texto="";
		String nombre="Alain";
		
		//booleanas
		boolean ventanaAbierta=true;
		boolean envaseAbierto=false;
		
	}

}
