package com.ipartek;

public class Ejemplo {

	
	public static void main(String[] args) {
		
		//xxxx resultado=0;
		int a=9;
		int b=-8;
		float c=7.9f;
		double d=7.32;
		char e='a';
		
		double operacion1=a+b+c+d;
		int operacion2=a-b-e;
		
		double operacion3=a+d/4;
		boolean operacion4=a-b>5*(d/a);
								
		
		System.out.println(operacion1);
		System.out.println(operacion2);
		System.out.println(operacion3);
		System.out.println(operacion4);
	}
	
	
}
