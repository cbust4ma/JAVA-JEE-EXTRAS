package com.ipartek;

public class BucleDOWHILE {

	public static void main(String[] args) {
		
		int dado=6;
		int contador=0;
		
		do
		{
			contador++;
			
			System.out.println(contador+": "+dado);
			dado=(int) (Math.random()*6+1);
		}while(dado!=6);
		
		
		
		

	}

}
