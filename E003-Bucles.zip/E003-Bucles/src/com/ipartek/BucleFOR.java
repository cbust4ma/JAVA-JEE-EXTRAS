package com.ipartek;

public class BucleFOR {

	public static void main(String[] args) {

		for (int i = 0; i < 5; i++) {

			System.out.println("hola"+i);
		}
		
		for (int i = 0; i <= 5; i++) {

			System.out.println("hola"+i);
		}
		
		for (int i = 1; i < 5; i++) {

			System.out.println("hola"+i);
		}
		
		for (int i = 1; i <= 500000; i++) {
			System.out.println("hola"+i);
		}

	}

}
