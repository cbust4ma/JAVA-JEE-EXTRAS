package com.ipartek;

public class BucleWHILE {

	public static void main(String[] args) {
		
		int dado=(int) (Math.random()*6+1);
		int contador=0;
		
		while(dado!=6)
		{
			
			contador++;
			
			System.out.println(contador+": "+dado);
			dado=(int) (Math.random()*6+1);
		}
		
		
		
	}

}
