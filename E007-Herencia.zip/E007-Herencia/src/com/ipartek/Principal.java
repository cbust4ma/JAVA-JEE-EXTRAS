package com.ipartek;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Zapato zapato1=new Zapato();
	Zapato zapato2=new Zapato("Cuero","sintetica");
	Zapato zapato3= new Zapato(39, 43.95, "zapato vestir", "Zapato marron de vestir", "Cuero", "Cuero");
	
	List<Zapato> zapateria=new ArrayList<Zapato>();
	zapateria.add(zapato1);
	zapateria.add(zapato2);
	zapateria.add(zapato3);
	
	
	Camisa camisa1= new Camisa("larga", "Algodon");
	Camisa camisa2= new Camisa("Corta", "lino");
	Camisa camisa3= new Camisa(44, 45, "camisa hawaiiana", "azul y con flores", "corta", "algodon");
	
	List<Camisa> camiseria=new ArrayList<Camisa>();
	camiseria.add(camisa1);
	camiseria.add(camisa2);
	camiseria.add(camisa3);
	
	
	Prenda prendaGenerica=new Prenda();
	
	
	List<Prenda> almacen=new ArrayList<Prenda>();
	almacen.add(zapato2);
	almacen.add(camisa3);
	almacen.add(prendaGenerica);
	
	System.out.println(zapato3);
	for (Prenda prenda : almacen) {
		if(prenda instanceof Zapato)
		{
			System.out.println("OBJETO DE CLASE ZAPATO");
		}
		else if(prenda instanceof Camisa) {
			System.out.println("OBJETO DE CLASE CAMISA");
		}else {
			System.out.println("OBJETO DE CLASE Prenda Generico");
		}
		
	}
	
	
	}

}
