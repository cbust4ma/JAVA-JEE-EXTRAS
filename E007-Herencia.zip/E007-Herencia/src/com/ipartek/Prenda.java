package com.ipartek;

public class Prenda {

	private int talla; //42, 50, 38
	private double precio;
	private String nombre;
	private String descripcion;
	
	public Prenda(int talla, double precio, String nombre, String descripcion) {
		super();
		this.talla = talla;
		this.precio = precio;
		this.nombre = nombre;
		this.descripcion = descripcion;
	}
	
	public Prenda() {
		super();
		this.talla = 0;
		this.precio = 0;
		this.nombre = "";
		this.descripcion = "";
	}

	public int getTalla() {
		return talla;
	}

	public void setTalla(int talla) {
		this.talla = talla;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "HOLA, soy una prenda de ropa";
	}
}
