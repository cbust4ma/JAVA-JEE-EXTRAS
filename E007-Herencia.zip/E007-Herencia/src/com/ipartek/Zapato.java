package com.ipartek;

public class Zapato extends Prenda {
	
	private String materialExterior;
	private String materialSuela;
	
	public Zapato(int talla, double precio, String nombre, String descripcion, String materialExterior,
			String materialSuela) {
		super(talla, precio, nombre, descripcion);
		this.materialExterior = materialExterior;
		this.materialSuela = materialSuela;
	}
	
	public Zapato() {
		super();
		this.materialExterior = "";
		this.materialSuela = "";
	}
	
	public Zapato(String materialExterior,String materialSuela) {
		super();
		this.materialExterior = materialExterior;
		this.materialSuela = materialSuela;
	}

	public String getMaterialExterior() {
		return materialExterior;
	}

	public void setMaterialExterior(String materialExterior) {
		this.materialExterior = materialExterior;
	}

	public String getMaterialSuela() {
		return materialSuela;
	}

	public void setMaterialSuela(String materialSuela) {
		this.materialSuela = materialSuela;
	}

	@Override
	public String toString() {
		return "Zapato [materialExterior=" + materialExterior + ", materialSuela=" + materialSuela + ", getTalla()="
				+ getTalla() + ", getPrecio()=" + getPrecio() + ", getNombre()=" + getNombre() + ", getDescripcion()="
				+ getDescripcion() + "]";
	}

	
	
	

}
