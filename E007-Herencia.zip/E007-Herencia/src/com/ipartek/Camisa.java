package com.ipartek;

public class Camisa extends Prenda{
	
	private String tipoManga;
	private String material;
	
	public Camisa(int talla, double precio, String nombre, String descripcion,
			String tipoManga, String material) {
		super(talla, precio, nombre, descripcion);
		this.tipoManga = tipoManga;
		this.material = material;
	}
	
	public Camisa() {
		super();
		this.tipoManga = "";
		this.material = "";
	}
	
	public Camisa(String tipoManga, String material) {
		super();
		this.tipoManga = tipoManga;
		this.material = material;
	}

	public String getTipoManga() {
		return tipoManga;
	}

	public void setTipoManga(String tipoManga) {
		this.tipoManga = tipoManga;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return "HOLA soy una camisa";
	}
	
	
	

}
