package com.ipartek2;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] listaNotas;
		String[] listaVerduras= new String[5];
		listaVerduras[0]="Alcachofas";
		listaVerduras[1]="Cebolla";
		listaVerduras[2]="Vainas";
		listaVerduras[3]="Coliflor";
		listaVerduras[4]="Acelgas";
		
		int[] notas= {7,3,7,3,8,9,10,1};
		
		int[] valoraciones= new int[6];
		
		for (int i = 0; i < valoraciones.length; i++) {
			System.out.println(valoraciones[i]);
		}
		
		boolean[] interruptores= new boolean[4];
		for (boolean elemento : interruptores) {
			
		}
		
		
		

		//version Alternativa
		int listaNotas2[];
		String listaVerduras2[]= new String[5];
		listaVerduras2[0]="alcachofas";
		listaVerduras2[1]="Cebolla";
		listaVerduras2[2]="Vainas";
		listaVerduras2[3]="Coliflor";
		listaVerduras2[4]="Acelgas";
		
		//System.out.println(listaNotas);
		System.out.println(listaVerduras);
		

	}

}
