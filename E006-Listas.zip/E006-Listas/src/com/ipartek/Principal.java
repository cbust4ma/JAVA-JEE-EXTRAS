package com.ipartek;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] listaCanciones = new String[12];

		List<String> listaMusica = new ArrayList<String>();

		listaMusica.add("Never gonna give you up");
		listaMusica.add("Thunderstruck");
		listaMusica.add("ride the lightning");
		listaMusica.add("The unforgiven");
		listaMusica.add("tu hamster");
		listaMusica.add("el baile de los gorilas");

		listaMusica.size();

		listaMusica.add(3, "1741");

		listaMusica.get(3);
		listaMusica.remove("1741");
		listaMusica.remove(2);

		listaMusica.set(1, "back in black");

		listaMusica.clear();
		listaMusica.contains("1741");
		
		

	}

}
