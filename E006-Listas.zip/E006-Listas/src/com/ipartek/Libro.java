package com.ipartek;

public class Libro {

	//atributos
	private String titulo;
	private String autor;
	private String id; 
	private short numPaginas;
	private float precio;
	private boolean prestado;
	
	//Constructores
	//constructor vacio
	public Libro()
	{
		this.titulo="";
		this.autor="";
		this.id="";
		this.numPaginas=0;
		this.precio=0;
		this.prestado=false;	
	}
	
	//constructor completo
	public Libro(String titulo,String autor,String id, 
			short numPaginas, float precio, boolean prestado)
	{
		this.titulo=titulo;
		this.autor=autor;
		this.id=id;
		this.numPaginas=numPaginas;
		this.precio=precio;
		this.prestado=prestado;	
	}
	
	//Getters y setters
	public String getTitulo() {
		return this.titulo;
	}
	
	public void setTitulo(String titulo) {
		this.titulo=titulo;
	}
	
	public String getAutor() {
		return this.autor;
	}
	
	public void setAutor(String autor) {
		this.autor=autor;
	}
	
	public String getId() {
		return this.id;
	}
	
	public void setId(String id) {
		this.id=id;
	}
	
	public short getNumPaginas() {
		return this.numPaginas;
	}
	
	public void setNumPaginas(Short numPaginas)
	{
		this.numPaginas=numPaginas;
	}
	
	public float getPrecio() {
		return this.precio;
	}
	
	public void setNumPaginas(float precio)
	{
		this.precio=precio;
	}
	
	public boolean getPrestado()
	{
		return this.prestado;
	}
	
	public void setPrestado(boolean prestado)
	{
		this.prestado=prestado;
	}
}
